from setuptools import setup, find_packages

setup(
    name="src", 
    version="0.0.1",
    description="Its a wine quality test machine learning project using mlops",
    author="codejay411",
    packages=find_packages(),
    license ="MIT"
)